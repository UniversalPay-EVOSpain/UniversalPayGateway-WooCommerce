﻿=== Universalpay Gateway for WooCommerce ===

Contributors: Javier Bartolome

Tags: woocommerce, servired, universalpay, credit card, martercard, visa, ecommerce

Requires at least: 3.5

Tested up to: 5.4.2

Stable tag: 1.1.9

License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


Integración para WooCommerce del sistema de pago Universalpay


== Description ==

